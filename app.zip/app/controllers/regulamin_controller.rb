class RegulaminController < ApplicationController
end
