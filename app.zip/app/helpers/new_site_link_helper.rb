module NewSiteLinkHelper
end
