module RegulaminHelper
end
