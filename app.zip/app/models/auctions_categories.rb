class AuctionsCategories < ActiveRecord::Base
end
