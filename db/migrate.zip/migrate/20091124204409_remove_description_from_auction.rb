class RemoveDescriptionFromAuction < ActiveRecord::Migration
  def self.up
    remove_column :auctions, :description
  end

  def self.down
    add_column :auctions, :description, :text, :null => false
  end
end
