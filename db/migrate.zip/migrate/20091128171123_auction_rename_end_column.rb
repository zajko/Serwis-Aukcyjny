class AuctionRenameEndColumn < ActiveRecord::Migration
  def self.up
    rename_column :auctions, :end, :auction_end
  end

  def self.down
    rename_column :auctions, :auction_end, :end
  end
end
