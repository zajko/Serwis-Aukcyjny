class AuctionAddCurrentPriceAndTimeOfService < ActiveRecord::Migration
  def self.up
    add_column :auctions, :current_price, :decimal, :precision => 14, :scale => 4, :default =>  0.0, :null => false
    add_column :auctions, :time_of_service, :integer, :default => 50, :null => false
    execute "ALTER TABLE Auctions ADD CONSTRAINT cs_time_of_service_greater_than_0 CHECK (time_of_service > 0);"
    execute "ALTER TABLE Auctions ADD CONSTRAINT cs_current_price_gte_0 CHECK (current_price >= 0);"
  end

  def self.down
    execute "ALTER TABLE Auctions DROP CONSTRAINT cs_time_of_service_greater_than_0;"
    execute "ALTER TABLE Auctions DROP CONSTRAINT cs_current_price_gte_0;"
    remove_column :auctions, :time_of_service
    remove_column :auctions, :current_price
  end
end
