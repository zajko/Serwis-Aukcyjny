
require File.dirname(__FILE__) + '/../test_helper'



class NewSiteLinkControllerTest < ActionController::TestCase
  # Replace this with your real tests.
  test "the truth" do
    assert true
  end
end
