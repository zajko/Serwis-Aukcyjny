#require 'test_helper'
require File.dirname(__FILE__) + '/../test_helper'


class BidObserverTest < ActiveSupport::TestCase


  def test_true
    assert true
  end
end
