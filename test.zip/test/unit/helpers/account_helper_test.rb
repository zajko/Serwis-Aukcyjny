require 'test_helper'

class AccountHelperTest < ActionView::TestCase
end
