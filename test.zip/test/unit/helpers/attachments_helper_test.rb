require 'test_helper'

class AttachmentsHelperTest < ActionView::TestCase
end
