require 'test_helper'

class AuctionsHelperTest < ActionView::TestCase
end
