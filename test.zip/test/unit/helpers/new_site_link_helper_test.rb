require 'test_helper'

class NewSiteLinkHelperTest < ActionView::TestCase
end
