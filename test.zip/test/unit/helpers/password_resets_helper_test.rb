require 'test_helper'

class PasswordResetsHelperTest < ActionView::TestCase
end
