require 'test_helper'

class RegulaminHelperTest < ActionView::TestCase
end
