require 'test_helper'

class RoleHelperTest < ActionView::TestCase
end
