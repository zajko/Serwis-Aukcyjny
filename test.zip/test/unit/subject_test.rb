#require 'test_helper'
require File.dirname(__FILE__) + '/../test_helper'

class SubjectTest < ActiveSupport::TestCase
  # Replace this with your real tests.
  test "the truth" do
    assert true
  end
end
